from pubmed import fetch_pubmed_articles

def main():
    query = input("Enter a search query for PubMed: ")
    articles = fetch_pubmed_articles(query)

    if not articles:
        print("No articles retrieved.")
        return

    for idx, article in enumerate(articles, start=1):
        print(f"\nArticle {idx}")
        print(f"PMID: {article['pmid']}")
        print(f"Title: {article['title']}")
        print(f"Abstract: {article['abstract']}")

if __name__ == "__main__":
    main()