# Aganitha Take Home

This is a simple Python script that fetches PubMed articles based on a search query using the NCBI E-utilities API.

## How to Run

1. Make sure you have Python installed (version 3.7+ recommended).
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run the script:
   ```
   python main.py
   ```

4. Enter a search term when prompted, and the script will show top PubMed articles.

## Files

- `main.py`: Main script that runs the search.
- `pubmed.py`: Contains functions to call the PubMed API and parse results.
- `requirements.txt`: Lists required Python packages.