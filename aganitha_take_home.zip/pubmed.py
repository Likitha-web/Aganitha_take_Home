import requests
from xml.etree import ElementTree as ET

def fetch_pubmed_articles(query, max_results=5):
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
    
    # Step 1: Search PubMed for the query
    search_url = f"{base_url}esearch.fcgi"
    search_params = {
        "db": "pubmed",
        "term": query,
        "retmax": max_results,
        "retmode": "json"
    }
    search_response = requests.get(search_url, params=search_params)
    search_data = search_response.json()
    id_list = search_data["esearchresult"]["idlist"]

    if not id_list:
        print("No articles found.")
        return []

    # Step 2: Fetch article details
    fetch_url = f"{base_url}efetch.fcgi"
    fetch_params = {
        "db": "pubmed",
        "id": ",".join(id_list),
        "retmode": "xml"
    }
    fetch_response = requests.get(fetch_url, params=fetch_params)
    articles = parse_pubmed_xml(fetch_response.text)
    return articles

def parse_pubmed_xml(xml_data):
    root = ET.fromstring(xml_data)
    articles = []

    for article in root.findall(".//PubmedArticle"):
        title = article.findtext(".//ArticleTitle", default="No title")
        abstract = article.findtext(".//AbstractText", default="No abstract")
        pmid = article.findtext(".//PMID", default="No PMID")

        articles.append({
            "pmid": pmid,
            "title": title,
            "abstract": abstract
        })

    return articles